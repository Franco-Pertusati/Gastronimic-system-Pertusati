// Obtener todos los elementos con la clase 'dragableElement'
const dragElements = document.querySelectorAll('.dragableElement');

let initialX = 0,
    initialY = 0;
let moveElement = false;

let events = {
    mouse: {
        down: "mousedown",
        move: "mousemove",
        up: "mouseup",
    },
    touch: {
        down: "touchstart",
        move: "touchmove",
        up: "touchend",
    }
};

let deviceType = "";

const isTouchDevice = () => {
    try {
        document.createEvent("TouchEvent");
        deviceType = "touch";
        return true;
    }
    catch(e) {
        deviceType = "mouse";
        return false;
    }
}

isTouchDevice();

// Función para manejar el movimiento del elemento
const handleDrag = (element) => {
    element.addEventListener(events[deviceType].down, (e) => {
        e.preventDefault();
        initialX = !isTouchDevice() ? e.clientX : e.touches[0].clientX;
        initialY = !isTouchDevice() ? e.clientY : e.touches[0].clientY;

        moveElement = true;
    });

    element.addEventListener(events[deviceType].move, (e) => {
        if (moveElement) {
            e.preventDefault();
            let newX = !isTouchDevice() ? e.clientX : e.touches[0].clientX;
            let newY = !isTouchDevice() ? e.clientY : e.touches[0].clientY;
            element.style.top =
                element.offsetTop - (initialY - newY) + "px";
            element.style.left =
                element.offsetLeft - (initialX - newX) + "px";
            initialX = newX;
            initialY = newY;
        }
    });

    element.addEventListener(events[deviceType].up, () => {
        moveElement = false;
    });

    element.addEventListener("mouseleave", () => {
        moveElement = false;
    });
};

// Agregar event listeners a cada elemento con la clase 'dragableElement'
dragElements.forEach((element) => {
    handleDrag(element);
});
