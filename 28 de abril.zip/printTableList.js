//Si a es true es una preOrder lo que hay que imprimir

function printTableList(a) {
    let container;
    let total;
    let itemsToPrint;
  
    if (a) {
      container = document.querySelector(".preOrdersList");
      total = document.querySelector("#subTotal");
      itemsToPrint = preOrder;
    } else {
      document.querySelector(".preOrdersList").innerHTML = "";
      document.querySelector("#subTotal").innerHTML = "";
      container = document.querySelector("#tableContent");
      total = document.querySelector("#tableTotal");
      itemsToPrint = selectedTableJS.items;
    }
  
    container.innerHTML = "";
    total.innerHTML = "";
    const productCounts = {};
    let subTotal = 0;
  
    itemsToPrint.forEach((product) => {
      subTotal += parseFloat(product.price); // Convertir el precio a número
      if (product.name in productCounts) {
        productCounts[product.name]++;
      } else {
        productCounts[product.name] = 1;
      }
    });
  
    for (const productName in productCounts) {
      const quantity = productCounts[productName];
      const newProduct = document.createElement("div");
      const p1 = document.createElement("p");
      const p2 = document.createElement("p");
      newProduct.classList.add("listElement");
      newProduct.classList.add("prodItem");
      newProduct.appendChild(p1);
      newProduct.appendChild(p2);
      p1.textContent = "x" + quantity + " " + productName;
      p2.textContent =
        "$" +
        (itemsToPrint.find((p) => p.name === productName).price * quantity); // No es necesario multiplicar por quantity aquí, ya que ya se hizo en el cálculo de subTotal
      container.appendChild(newProduct);
    }
    total.textContent = "$" + subTotal.toFixed(2); // Redondear el total a 2 decimales
    if (!a) {
      selectedTableJS.total = subTotal; // Actualizar el total en el objeto selectedTableJS solo si no es una preOrden
    }
  }