document.addEventListener("DOMContentLoaded", function () {
  var groups = [];
  var tables = [];
  var preOrder = [];
  var selectedTable = null;
  var selectedTableJS = null;
  var transactionsList = [];
  var paymentMethods = ["Efectivo"];
  var ingredientsList = [];
  var barName = "El Despa";

  slotCreation();
  printGroupArrayMenu();
  printPaymentsMethodsList();
  printAllIngredients();
  fillPaymentsMethodsSlct();
  if (localStorage.getItem("tables")) {
    loadTables();
  } else {
    createTable("start");
  }

  if (localStorage.getItem("groups")) {
    console.log("grupos guardados en ls " + localStorage.getItem("groups"));
    loadGroups();
  }

  document.querySelector(".delTable").addEventListener("click", function () {
    createTable("start");
  });

  //Creacion de grupos
  document
    .querySelector("#createGroupArray")
    .addEventListener("click", function () {
      const gName = document.querySelector("#aNameInput").value.trim();
      if (gName != "") {
        createGroup(gName);
      }
    });

  function createGroup(gName) {
    const group = { name: gName, products: [] };
    groups.push(group);
    printGroupArrayMenu();
    //Limpieza de imputs
    document.querySelector("#aNameInput").value = "";
    saveData("groups", groups);
  }

  function createProduct(pName, pPrice, pGroup, pIngredients) {
    const product = { name: pName, price: pPrice, ingredients: pIngredients };
    var selectedGroup = groups.find((group) => group.name === pGroup);
    selectedGroup.products.push(product);
    printGroupArrayMenu();
    saveData("groups", groups);
  }

  //Creacion de productos
  document
    .querySelector("#createProductArray")
    .addEventListener("click", function () {
      const pName = document.querySelector("#aNameInput2").value.trim();
      const pPrice = document.querySelector("#aPriceInput").value.trim();
      const pGroup = document.querySelector("#GroupSelect").value.trim();

      if (pName && pPrice != "") {
        createProduct(pName, pPrice, pGroup, "");
        //Limpieza de imputs
        document.querySelector("#aNameInput2").value = "";
        document.querySelector("#aPriceInput").value = "";
      }
    });

  // Creación de los hueco/slots para las mesas
  function slotCreation() {
    const itemName = "salonDistribution";
    const containerId = "salonConteiner";
    var salonGrid = document.querySelector(".salon");
    var salonClass = window.getComputedStyle(salonGrid);
    var numColumns = parseInt(
      salonClass.getPropertyValue("grid-template-columns").split(" ").length
    );
    var numRows = parseInt(
      salonClass.getPropertyValue("grid-template-rows").split(" ").length
    );
    // Slots necesarios para generar
    var totalSlots = numColumns * numRows;
    for (var i = 0; i < totalSlots; i++) {
      const slot = document.createElement("div");
      slot.id = "slot" + i; // Modificación para que el ID sea único
      slot.classList.add("slot");
      slot.addEventListener("dragover", function (event) {
        event.preventDefault();
      });
      salonGrid.appendChild(slot);
      slot.addEventListener("drop", function (event) {
        event.preventDefault();
        var tableId = event.dataTransfer.getData("text/plain"); // Cambiado para ser más específico
        var table = document.getElementById(tableId);
        if (table.parentElement.classList.contains("tableTool")) {
          // Verificar si la mesa no está en un slot antes de agregar una nueva mesa
          createTable("start");
        }
        event.target.appendChild(table);
        table.setAttribute("data-position", event.target.id);
        //Registro de posiciones de mesas
        tableToUpdate = tables[table.id];
        tableToUpdate.position = event.target.id;
        saveData("tables", tables);
      });
    }
  }

  //Creacion de mesas
  function createTable(position) {
    const tName = tables.length;
    const table = { name: tName, items: [], ocuped: false, position: "start" };
    const container = document.querySelector(".tableTool");
    const newTable = document.createElement("div");
    newTable.classList.add("squareButton");
    newTable.classList.add("table");
    newTable.id = tName;
    newTable.textContent = tName + 1;
    newTable.draggable = true;
    if (position === "start") {
      container.appendChild(newTable);
      table.position = "start";
    } else {
      const conteiner = document.getElementById(position);
      conteiner.appendChild(newTable);
      //Cuando las mesas se crean mediante la funcion loadTables no se les agrega una data-position
      newTable.setAttribute("data-position", position);
      table.position = position;
    }
    newTable.addEventListener("dragstart", function (event) {
      event.dataTransfer.setData("text/plain", event.target.id);
    });
    tables.push(table);
    //Seleccion de mesas
    newTable.addEventListener("click", function () {
      if (selectedTable) {
        // Si hay una mesa seleccionada, quitar la clase tableSelected
        selectedTable.classList.remove("tableSelected");
      }
      newTable.classList.add("tableSelected");
      selectedTable = newTable;
      tIndex = selectedTable.textContent - 1;
      selectedTableJS = tables[selectedTable.id];
      console.log(selectedTableJS.name);
      //Mostrar la mesa seleccionada en el menu de mesa
      const selectedTableDisplay = document.querySelectorAll(".selectedTable");
      selectedTableDisplay.forEach((a) => {
        a.textContent = "Mesa seleccionada: " + selectedTable.textContent;
        // Se actualiza el muestreo del inventario de la mesa
      });
      printPreorder();
    });
  }

  var selectedProd = null;

  //Imprimir los arrays de la carta
  function printGroupArrayMenu(pName, pPrice) {
    const conteiner = document.querySelector("#groupConteiner");
    const selectElement = document.querySelector("#GroupSelect");
    conteiner.innerHTML = "";
    selectElement.innerHTML = "";
    //Esta es la forma de imprimir para la ventana de la carta
    //y llenar el elemento select
    groups.forEach((group) => {
      //Primero imprimimos en el DOM el listado de grupos
      const newGroup = document.createElement("div");
      const groupContent = document.createElement("div");
      newGroup.classList.add("listElement");
      newGroup.classList.add("group");
      newGroup.classList.add("background");
      newGroup.textContent = group.name + ":";
      newGroup.appendChild(groupContent);
      conteiner.appendChild(newGroup);
      //Segundo añadimos una opcion a nuestro select por cada grupo que creamos
      const option = document.createElement("option");
      option.value = group.name;
      option.text = group.name;
      selectElement.appendChild(option);
      //Ahora se procede a agregarle los items a cada grupo
      group.products.forEach((product) => {
        const newProduct = document.createElement("div");
        newProduct.classList.add("listElement");
        newProduct.classList.add("groupElement");
        const p1 = document.createElement("p");
        const p2 = document.createElement("p");
        const groupBtn = document.createElement("div");
        const groupBtn2 = document.createElement("div");
        const btnIco = document.createElement("ion-icon");
        const btnIco2 = document.createElement("ion-icon");
        btnIco.setAttribute("name", "trash-outline");
        btnIco2.setAttribute("name", "create-outline");
        groupBtn.appendChild(btnIco);
        groupBtn2.appendChild(btnIco2);
        p1.textContent = product.name;
        p2.textContent = "$" + product.price;
        newProduct.appendChild(p1);
        newProduct.appendChild(p2);
        newProduct.appendChild(groupBtn);
        newProduct.appendChild(groupBtn2);
        groupContent.appendChild(newProduct);
        //Funcionalidad de el boton de borrar producto
        btnIco.addEventListener("click", function () {
          groupContent.removeChild(newProduct);
          const prodToRemove = groups
            .flatMap((group) => group.products)
            .find((product) => p1.textContent === product.name);
          // Filtra el array groups para excluir el objeto prodToRemove
          groups.forEach((group) => {
            group.products = group.products.filter(
              (product) => product !== prodToRemove
            );
          });
          saveData("groups", groups);
        });
        //Funcionalidad del boton de editar producto y añadirle ingredientes
        btnIco2.addEventListener("click", function () {
          const prodToEdit = groups
            .flatMap((group) => group.products)
            .find((product) => p1.textContent === product.name);
          // Filtra el array groups para excluir el objeto prodToRemove
          selectedProd = prodToEdit;
          printSelectedIngredients();
          //Ahora se renderizan los datos en los inputs de edicion
          const nameInput = document.querySelector("#prodNameToEdit");
          const priceInput = document.querySelector("#prodPriceToEdit");

          nameInput.value = selectedProd.name;
          priceInput.value = selectedProd.price;

          document
            .querySelector("#apllyNewData")
            .addEventListener("click", function () {
              selectedProd.name = nameInput.value;
              selectedProd.price = priceInput.value;
              printGroupArrayMenu();
              nameInput.value = "";
              priceInput.value = "";
              selectedProd = null;
              document.querySelector("#huecoIngredientesProd").innerHTML = "";
              saveData("groups", groups);
            });
        });
      });
    });
  }

  var selectedBtn = null;

  //Impresion de grupos y productos en la ventana del inventario de mesa
  function printMenuInTable(groupTabs, productsConteiner) {
    groupTabs.innerHTML = "";
    groups.forEach((group) => {
      const newGroupBtn = document.createElement("button");
      newGroupBtn.classList.add("squareButton");
      newGroupBtn.textContent = group.name;
      groupTabs.appendChild(newGroupBtn);
      newGroupBtn.addEventListener("click", function () {
        if (selectedBtn) {
          selectedBtn.classList.remove("selectedBtn");
        }
        newGroupBtn.classList.add("selectedBtn");
        selectedBtn = newGroupBtn;
        groupSelected = newGroupBtn.textContent;
        productsConteiner.innerHTML = "";
        const groupToPrint = groups.find(
          (group) => group.name === groupSelected
        );
        groupToPrint.products.forEach((product) => {
          const newProduct = document.createElement("button");
          const p1 = document.createElement("p");
          const p2 = document.createElement("p");
          p1.textContent = product.name;
          p2.textContent = "$" + product.price;
          newProduct.appendChild(p1);
          newProduct.appendChild(p2);
          newProduct.setAttribute("data-name", product.name);
          productsConteiner.appendChild(newProduct);
          newProduct.addEventListener("click", function () {
            //Se añanden a una lista los objetos que queremos cargar a la mesa
            const allProducts = groups.flatMap((group) => group.products);
            const productToAdd = allProducts.find(
              (a) => a.name === product.name
            );
            preOrder.push(productToAdd);
            printPreorder();
          });
        });
      });
    });
  }

  //Funcion para imprimir todo lo que esta en preOrder y mostrarlo de forma que los items repetidos se apilen
  //Todo lo que esta en preOrder son items que no se confirmo su pedido
  function printPreorder() {
    const preOrderItemsList = document.querySelector("#preOrderItemsList");
    const total = document.querySelector("#subTotal");

    preOrderItemsList.innerHTML = "";
    const productCounts = {};
    var subTotal = 0;

    preOrder.forEach((product) => {
      subTotal += parseFloat(product.price); // Convertir el precio a número
      if (product.name in productCounts) {
        productCounts[product.name]++;
      } else {
        productCounts[product.name] = 1;
      }
    });

    for (const productName in productCounts) {
      const quantity = productCounts[productName];
      const newProduct = document.createElement("div");
      const p1 = document.createElement("p");
      const p2 = document.createElement("p");
      newProduct.classList.add("listElement");
      newProduct.classList.add("prodItem");
      newProduct.appendChild(p1);
      newProduct.appendChild(p2);
      p1.textContent = "x" + quantity + " " + productName;
      p2.textContent =
        "$" + preOrder.find((p) => p.name === productName).price * quantity; // No es necesario multiplicar por quantity aquí, ya que ya se hizo en el cálculo de subTotal
      preOrderItemsList.appendChild(newProduct);
    }
    total.textContent = "$" + subTotal.toFixed(2); // Redondear el total a 2 decimales
  }

  //Funcionalidad de boton de comandar y cancelar comanda
  const comandarBtn = document.querySelector(".comandar");
  const cancelarComandaBtn = document.querySelector(".cancelarComanda");

  comandarBtn.addEventListener("click", function () {
    selectedTableJS.items.push(...preOrder);
    preOrder = [];
    if (selectedTableJS.items.length > 0) {
      selectedTable.classList.add("ocuped");
      selectedTableJS.ocuped = true;
    }
  });
  cancelarComandaBtn.addEventListener("click", function () {
    preOrder = [];
    printTableList();
  });

  document
    .querySelector("#createExpense")
    .addEventListener("click", function () {
      // Declaramos el input de el motivo y próximamente del método de pago
      const reason = document.querySelector("#expenseReason").value;
      const num = document.querySelector("#expenseAmount").value;

      const amount = num * -1;

      pm = document.querySelector(".PM3").value;

      // Ahora limpiamos todos los inputs
      document.querySelector("#expenseAmount").value = ""; // Limpiamos el input de amount
      document.querySelector("#expenseReason").value = ""; // Limpiamos el input de reason

      // con esta función se manda a imprimir el array en el DOM
      if (reason && amount != "") {
        createTransaction(amount, reason, pm);
      }
    });

  document
    .querySelector("#createIncome")
    .addEventListener("click", function () {
      // Declaramos el input de el motivo y próximamente del método de pago
      const reason = document.querySelector("#incomeReason").value;
      const amount = document.querySelector("#incomeAmount").value;
      // Convertimos amount a un número decimal

      // Ahora limpiamos todos los inputs
      document.querySelector("#incomeAmount").value = ""; // Limpiamos el input de amount
      document.querySelector("#incomeReason").value = ""; // Limpiamos el input de reason

      pm = document.querySelector(".PM2").value;

      // con esta función se manda a imprimir el array en el DOM
      if (reason && amount != "") {
        createTransaction(amount, reason, pm);
      }
    });

  //Confirmar cierre de mesa
  document.querySelector("#closeTable").addEventListener("click", function () {
    paymentMethod = document.querySelector(".PM1").value;
    closeTable(selectedTableJS, paymentMethod);
  });

  function closeTable(tableToClose, paymentMethod) {
    amount = tableToClose.total;
    //Creamos el ticket en una pestaña nueva
    createTicket(tableToClose.items, tableToClose.total, tableToClose.name);
    tableToClose.items = [];
    tableToClose.total = 0;
    printTableList();
    document.querySelector("#askCloseTable").classList.add("hide");
    tableToClose.ocuped = false;
    //Buscamos el elemento html que representa esta mesa para completar algunos datos y mostrarla como vacia
    const htmlTables = document.querySelectorAll(".table");
    const selectedHtmlTable = Array.from(htmlTables).find(
      (table) => table.id === tableToClose.name.toString()
    );
    selectedHtmlTable.classList.remove("ocuped");
    pm = paymentMethod;
    reason = "Mesa: " + selectedHtmlTable.textContent;
    createTransaction(amount, reason, pm);
    console.log(selectedHtmlTable.id + tableToClose.name);
  }

  function createTicket(items, total, name) {
    // Construir el contenido del ticket
    const ticketContent = `
        <html>
        <head>
            <title>Ticket de Mesa: X</title>
        </head>
        <body>
            <h1>${barName} - Mesa: ${name + 1}</h1>
            <div></div>
            <ul>
                ${items
                  .map((item) => `<li>${item.name}: $${item.price}</li>`)
                  .join("")}
            </ul>
            <div></div>
            <p class="total">Total: $${total}</p>
            <p>Ticket comanda (no valido como factura)</p>
            <p>Fecha: ${day}/${month}/${year}</p>
        </body>
        </html>
        <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
    }
    div {
      border: dashed 1px black
    }
    h1, .total {
        text-align: center;
        font-size: 32px;
    }

    ul {
        list-style-type: none;
        padding: 0;
    }

    li {
        margin-bottom: 5px;
        list-style: none;
    }

    p {
        margin-top: 20px;
        text-align: center;
    }
</style>

    `;

    // Abrir una nueva pestaña con el contenido del ticket
    const ticketWindow = window.open("", "_blank", "width=400,height=600");
    ticketWindow.document.write(ticketContent);
    ticketWindow.document.close();
  }

  const date = new Date();
  const day = date.getDate();
  // Los meses en JavaScript son indexados desde 0
  const month = date.getMonth() + 1;
  const year = date.getFullYear();

  function createTransaction(amount, reason, pm) {
    const transaction = {
      reason: reason,
      amount: amount,
      paymentMethod: pm,
      date: new Date(),
    };
    transactionsList.push(transaction);
    printTransactions();
    let balance = 0;
    const conteiner = document.querySelector(".paymentsHistoryResult");
    transactionsList.forEach((transaction) => {
      balance += parseInt(transaction.amount);
    });

    conteiner.textContent =
      "Balance: $" +
      balance +
      " - - - " +
      "Fecha: " +
      day +
      "/" +
      month +
      "/" +
      year;

    document.querySelector("#totalMoney").textContent = "$" + balance;
  }

  function printTransactions() {
    const listConteiner = document.querySelector(".paymentsHistoryList");
    listConteiner.innerHTML = "";
    transactionsList.forEach((transaction) => {
      const newTransaction = document.createElement("div");
      const fecha = transaction.date;
      const horas = fecha.getHours();
      const minutos = fecha.getMinutes();
      const p1 = document.createElement("p");
      const p2 = document.createElement("p");
      const p3 = document.createElement("p");
      const p4 = document.createElement("p");
      p1.textContent = "$ " + transaction.amount;
      if (transaction.amount > 0) {
        p1.textContent = "$ +" + transaction.amount;
        p1.classList.add("positiveAmount");
        p2.classList.add("positiveAmount");
        p3.classList.add("positiveAmount");
        p4.classList.add("positiveAmount");
      } else {
        p1.classList.add("negativeAmount");
        p2.classList.add("negativeAmount");
        p3.classList.add("negativeAmount");
        p4.classList.add("negativeAmount");
      }
      p2.textContent = transaction.reason;
      p3.textContent = horas + ":" + minutos;
      p4.textContent = transaction.paymentMethod;
      listConteiner.appendChild(newTransaction);
      newTransaction.appendChild(p1);
      newTransaction.appendChild(p2);
      newTransaction.appendChild(p4);
      newTransaction.appendChild(p3);
      newTransaction.classList.add("transaction");
    });
  }

  //Creacion de metodos de pago
  const paymentMethodName = document.querySelector("#paymentMethodName");
  document
    .querySelector("#addPaymenMethod")
    .addEventListener("click", function () {
      paymentMethods.push(paymentMethodName.value);
      printPaymentsMethodsList();
      paymentMethodName.value = "";
    });

  //Funcion para imprimir los metodos de pago en la lista del menu

  function printPaymentsMethodsList() {
    const conteiner = document.querySelector(".paymentsMethodsList");
    conteiner.innerHTML = "";

    paymentMethods.forEach((element, index) => {
      const newPM = document.createElement("div");
      newPM.classList.add("pm");
      newPM.textContent = element;

      // Agregar el botón de eliminación
      const delBtn = document.createElement("button");
      delBtn.addEventListener("click", function () {
        // Eliminar el elemento PM y del array cuando se hace clic en el botón de eliminación
        conteiner.removeChild(newPM);
        paymentMethods.splice(index, 1); // Eliminar el elemento del array
      });
      newPM.appendChild(delBtn);

      // Agregar el icono
      const tCan = document.createElement("ion-icon");
      tCan.setAttribute("name", "trash-outline"); // Usar setAttribute para establecer el nombre del ícono
      delBtn.appendChild(tCan);

      conteiner.appendChild(newPM);
    });
    fillPaymentsMethodsSlct();
  }

  //Creacion de ingredientes
  document
    .querySelector("#createIngredient")
    .addEventListener("click", function () {
      const ingredientName = document.querySelector("#ingredientName");
      //Comprobamos que el input no este vaico
      if (ingredientName.value != "") {
        const ingredient = ingredientName.value;
        ingredientsList.push(ingredient);
        printAllIngredients();
        printSelectedIngredients();
      }
      ingredientName.value = "";
    });

  function printAllIngredients() {
    const conteiner = document.querySelector("#allIngrdients");
    conteiner.innerHTML = "";

    ingredientsList.forEach((ingredient) => {
      const newIngedient = document.createElement("div");
      newIngedient.textContent = ingredient;
      newIngedient.classList.add("ingredients");
      const delBtn = document.createElement("button");
      delBtn.textContent = "del";
      delBtn.classList.add("softBtn");
      const addBtn = document.createElement("button");
      addBtn.textContent = "add";
      addBtn.classList.add("softBtn");
      conteiner.appendChild(newIngedient);
      newIngedient.appendChild(delBtn);
      newIngedient.appendChild(addBtn);
      addBtn.addEventListener("click", function () {
        if (selectedProd != null) {
          selectedProd.ingredients.push(ingredient);
          console.log(selectedProd);
          printSelectedIngredients();
        }
      });
    });
  }

  function printSelectedIngredients() {
    const conteiner = document.querySelector("#huecoIngredientesProd");
    conteiner.innerHTML = "";

    selectedProd.ingredients.forEach((ingredient) => {
      const newIngedient = document.createElement("div");
      newIngedient.textContent = ingredient;
      newIngedient.classList.add("ingredients");
      const delBtn = document.createElement("button");
      delBtn.textContent = "del";
      delBtn.classList.add("softBtn");
      conteiner.appendChild(newIngedient);
      newIngedient.appendChild(delBtn);
    });
  }

  //Funcion para cerrar todas las mesas
  document
    .querySelector("#closeAllTables")
    .addEventListener("click", function () {
      var ocupedTables = tables.filter((table) => table.ocuped === true);
      ocupedTables.forEach((ot) => {
        closeTable(ot);
      });
    });

  //------------------------------------- menuMagnament --------------------------

  document.querySelectorAll("#cashierSell").forEach((btn) => {
    btn.addEventListener("click", function () {
      const groupTabs = document.querySelector("#gt2");
      const productsConteiner = document.querySelector("#pc2");
      printMenuInTable(groupTabs, productsConteiner);
      const window = document.querySelector("#sellFromcashier");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#cartaWinSwitch").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector("#cartaWin");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#cajaCtrlBtn").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector(".cajaCtrl");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#paymentsMethodsBtn").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector("#paymentsMethods");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#paymentsHistoryBtn").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector(".paymentsHistory");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#newPaymentBtn").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector("#newPayment");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#newPaymentBtn2").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector("#newPayment2");
      openCloseWindows(window);
    });
  });

  document.querySelectorAll("#openTableInventoryMenu").forEach((btn) => {
    btn.addEventListener("click", function () {
      if (selectedTable === null) {
        alert("Seleccione una mesa");
      } else {
        const window = document.querySelector("#tableInventory");
        openCloseWindows(window);
        const groupTabs = document.querySelector(".groupsTabs");
        const productsConteiner = document.querySelector(".productButtons");
        printMenuInTable(groupTabs, productsConteiner);
        printPreorder();
      }
    });
  });

  document.querySelectorAll("#close1").forEach((btn) => {
    btn.addEventListener("click", function () {
      if (selectedTable === null) {
        alert("Seleccione una mesa");
      } else {
        const window = document.querySelector("#askCloseTable");
        openCloseWindows(window);
      }
    });
  });

  const panelSalonbtns = document.querySelectorAll("#panelSalonbtn");
  const panelSalonWindows = document.querySelectorAll("#panelSalonPag");

  switchWindows(panelSalonWindows, panelSalonbtns);

  document.querySelectorAll("#openCloseSwap").forEach((btn) => {
    btn.addEventListener("click", function () {
      const window = document.querySelector("#swapTablesWin");
      openCloseWindows(window);
      const select = document.querySelectorAll("#tablesSlct");
      select.forEach((slct) => {
        slct.innerHTML = "";
        tables.forEach((table) => {
          const option = document.createElement("option");
          option.value = table.name;
          option.text = table.name + 1;
          slct.appendChild(option);
        });
      });
    });
  });

  document.querySelector("#doSwap").addEventListener("click", function () {
    const table1 = document.querySelector(".table1").value;
    const table2 = document.querySelector(".table2").value;
    swapTables(table1, table2);
  });

  //Funcion para intercambiar los inventarios de las mesas
  function swapTables(table1, table2) {
    let table0 = [];
    tIndex1 = table1.textContent;
    tIndex2 = table2.textContent;
    realTable1 = tables[tIndex1 - 1];
    realTable2 = tables[tIndex2 - 1];
    realTable2.items.push(realTable1.items);
  }

  // Funcion que con una cantidad infinita de botones que hacen de switch para hacer desaparecer o aparecer un solo menú
  function openCloseWindows(window) {
    window.classList.toggle("hide");
  }

  // Funcion con la que se manejan varios menus con sus respectivos botones
  function switchWindows(windowsArray, buttonsArray) {
    if (windowsArray.length === buttonsArray.length) {
      Array.from(buttonsArray).forEach((btn, index) => {
        btn.addEventListener("click", function () {
          windowsArray.forEach((window) => {
            window.classList.add("hide");
          });
          windowsArray[index].classList.remove("hide");
        });
      });
    } else {
      console.log("La cantidad de pestañas y botones discrepa");
    }
  }

  //funcion para llenar todos los select con id #paymentsMethodsSlct con los metodos de pago
  function fillPaymentsMethodsSlct() {
    const selects = document.querySelectorAll("#paymentsMethodsSlct");
    selects.forEach((a) => {
      a.innerHTML = "";
    });
    paymentMethods.forEach((a) => {
      const newMethod = document.createElement("option");
      newMethod.textContent = a;
      newMethod.value = a;
      selects.forEach((select) => {
        select.appendChild(newMethod.cloneNode(true));
      });
    });
  }

  //--------------------StorageMagnament------------------------------>
  function saveData(itemName, dataTosave) {
    const stringifiedData = JSON.stringify(dataTosave);
    localStorage.setItem(itemName, stringifiedData);
  }

  function loadTables() {
    var tablesData = localStorage.getItem("tables");
    var tablesToPrint = JSON.parse(tablesData);
    tablesToPrint.forEach((table) => {
      if (table.position === "start") {
      } else {
        createTable(table.position);
      }
    });
    createTable("start");
  }

  function loadGroups() {
    var groupsData = localStorage.getItem("groups");
    var groupsToPrint = JSON.parse(groupsData);
    groupsToPrint.forEach((group) => {
      createGroup(group.name);
      group.products.forEach((product) => {
        createProduct(
          product.name,
          product.price,
          group.name,
          product.ingredients
        );
        console.log(product);
      });
    });
  }
});
